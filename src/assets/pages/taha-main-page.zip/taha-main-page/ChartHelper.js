function generateChartFromAPI(apiUrl, chartElementId) {
  const periode = [];
  const tauxFPM = [];
  const tauxFDD = [];
  const tauxREF = [];

  fetch(apiUrl)
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      const items = data.data.data[0].slice(0, 30);
      let k = 0;

      let lastTauxMax = null;
      let date1 = null;

      // Trouver la première date où TAUX_MAX change
      for (let i = items.length - 1; i >= 0; i--) {
        const tauxMax = items[i].TAUX_MAX.trim();
        if (lastTauxMax === null) {
          lastTauxMax = tauxMax;
        } else if (tauxMax !== lastTauxMax) {
          date1 = new Date(dateFrToEngDate(items[i].D_DATE));
          break;
        }
      }

      // S'il n’y a pas de changement, date1 reste null → utiliser dernière date
      if (!date1) {
        date1 = new Date(dateFrToEngDate(items[0].D_DATE));
      }

      for (let i = items.length - 1; i >= 0; i--) {
        const date2 = new Date(dateFrToEngDate(items[i].D_DATE));

        const tauxMax = parseFloat(items[i].TAUX_MAX);
        const tauxMin = parseFloat(items[i].TAUX_MIN);
        const tauxRef = parseFloat(items[i].TAUX);

        periode[k] = items[i].D_DATE;
        tauxFPM[k] = date2 >= date1 ? tauxMax : lastTauxMax;
        tauxFDD[k] = date2 >= date1 ? tauxMin : parseFloat(items[i].TAUX_MIN); // tu peux aussi fixer l'ancien si nécessaire
        tauxREF[k] = tauxRef;

        k += 1;
      }

      // Création du graphique
      const config = {
        type: "line",
        data: {
          labels: periode,
          datasets: [
            {
              label: "TAUX DES FACILITES DE PRET MARGINAL",
              data: tauxFPM,
              fill: false,
              borderColor: "#2f62bd",
              borderWidth: 2,
              pointRadius: 1,
            },
            {
              label: "TAUX DES FACILITES DES DEPOTS",
              data: tauxFDD,
              fill: false,
              borderColor: "#cf8a00",
              borderWidth: 2,
              pointRadius: 1,
            },
            {
              label: "TAUX DE REFERENCE",
              data: tauxREF,
              fill: false,
              borderColor: "#a4a4a4",
              borderWidth: 2,
              pointRadius: 1,
            },
          ],
        },
        options: {
          plugins: {
            legend: {
              display: false,
              position: "top",
            },
          },
          elements: {
            line: {
              tension: 0,
            },
          },
          layout: {
            padding: {
              left: 50,
              right: 50,
              top: 10,
              bottom: 10,
            },
          },
          scales: {
            x: {
              grid: {
                display: false,
              },
            },
            y: {
              grid: {
                display: false,
              },
            },
          },
        },
      };

      const ctx = document.getElementById(chartElementId).getContext("2d");
      new Chart(ctx, config);
    });
}

// Utilisation dans une page :
generateChartFromAPI(
  "https://www.banky-foibe.mg/admin/wp-json/bfm/taux_interbancaire_tous",
  "moisChart"
);